var form_id, app = getApp(), util = require("../../utils/util.js");

Page({
    data: {
        form_id: "",
        index: 0,
        inde: 0,
        array: [],
        showModal: !1,
        zftype: !0,
        zfz: !1,
        chzf: !1,
        zffs: 1,
        zfwz: "微信支付",
        btntype: "btn_ok1",
        beizhu: ""
    },
    ddbz: function(e) {
        console.log(e.detail.value), this.setData({
            beizhu: e.detail.value
        });
    },
    radioChange: function(e) {
        console.log("radio发生change事件，携带value值为：", e.detail.value), "wxzf" == e.detail.value && this.setData({
            zftype: !0,
            chzf: !1,
            zffs: 1,
            zfwz: "微信支付",
            btntype: "btn_ok1"
        }), "yezf" == e.detail.value && this.setData({
            zftype: !1,
            chzf: !1,
            zffs: 2,
            zfwz: "余额支付",
            btntype: "btn_ok2"
        }), "jfzf" == e.detail.value && this.setData({
            chzf: !1,
            zffs: 3,
            zfwz: "积分支付",
            btntype: "btn_ok3"
        }), "chzf" == e.detail.value && this.setData({
            chzf: !0,
            zffs: 4,
            zfwz: "餐后支付"
        });
    },
    xszz: function() {
        this.setData({
            showModal: !0
        });
    },
    yczz: function() {
        this.setData({
            showModal: !1
        });
    },
    qdzf: function() {
        console.log("确定支付");
    },
    jsmj: function(e, t) {
        for (var a, o = 0; o < t.length; o++) if (Number(e) >= Number(t[o].full)) {
            a = o;
            break;
        }
        return a;
    },
    onLoad: function(e) {
        var t = e.tableid;
        console.log(t);
        var a = this;
        app.util.request({
            url: "entry/wxapp/Zhuohao",
            cachetime: "0",
            data: {
                id: t
            },
            success: function(e) {
                console.log(e), a.setData({
                    tabletypename: e.data.type_name,
                    tablename: e.data.table_name,
                    table_id: t
                });
            }
        }), app.util.request({
            url: "entry/wxapp/TableType",
            cachetime: "0",
            success: function(e) {
                console.log(e), a.setData({
                    array: e.data
                });
            }
        }), app.util.request({
            url: "entry/wxapp/system",
            cachetime: "0",
            success: function(e) {
                console.log(e), a.setData({
                    jf_proportion: e.data.jf_proportion
                }), "1" == e.data.is_yue ? a.setData({
                    ptkqyue: !0
                }) : a.setData({
                    ptkqyue: !1
                }), "1" == e.data.is_jfpay ? a.setData({
                    ptkqjf: !0
                }) : a.setData({
                    ptkqjf: !1
                });
            }
        });
        var o = wx.getStorageSync("users").id;
        if (app.util.request({
            url: "entry/wxapp/UserInfo",
            cachetime: "0",
            data: {
                user_id: o
            },
            success: function(e) {
                console.log(e), a.setData({
                    wallet: e.data.wallet,
                    total_score: e.data.total_score
                });
            }
        }), app.util.request({
            url: "entry/wxapp/Url",
            cachetime: "0",
            success: function(e) {
                a.setData({
                    url: e.data
                });
            }
        }), null == e.preferential) s = 0; else var s = Number(e.preferential);
        console.log(s);
        var i = util.formatTime(new Date()), n = wx.getStorageSync("order"), l = wx.getStorageSync("store");
        console.log(n), console.log(l), "1" == l.is_yue ? a.setData({
            sjkqyue: !0
        }) : a.setData({
            sjkqyue: !1
        }), "1" == l.is_jfpay ? a.setData({
            sjkqjf: !0
        }) : a.setData({
            sjkqjf: !1
        });
        for (var c = 0, r = 0; r < n.length; r++) c += Number(n[r].money) * n[r].num;
        var u;
        app.util.request({
            url: "entry/wxapp/Reduction",
            cachetime: "0",
            data: {
                id: l.id
            },
            success: function(e) {
                console.log(e);
                for (var t = [], o = 0; o < e.data.length; o++) "2" != e.data[o].type && "3" != e.data[o].type || t.push(e.data[o]);
                console.log(t);
                var i = 0;
                if (0 == t.length) u = Number(c) - s - i, console.log(i); else if (Number(c) >= Number(t[t.length - 1].full)) {
                    console.log(a.jsmj(c, t));
                    var n = a.jsmj(c, t);
                    i = Number(t[n].reduction), console.log(i), u = Number(c) - s - i;
                } else u = Number(c) - s - i, console.log(i);
                u <= 0 && (u = .01), a.setData({
                    zfmoney: u.toFixed(2),
                    cut: i
                }), console.log(u);
            }
        }), a.setData({
            order: n,
            store: l,
            color: l.color,
            types: e.types,
            totalPrice: c,
            time: i,
            pre: s,
            coupons_id: e.coupons_id,
            vouchers_id: e.vouchers_id
        });
    },
    coupon: function(e) {
        var t = this;
        console.log(t.data), wx.navigateTo({
            url: "../coupons/mine_coupons?totalPrice=" + t.data.totalPrice + "&state=2&tableid=" + t.data.table_id,
            success: function(e) {},
            fail: function(e) {},
            complete: function(e) {}
        });
    },
    formSubmit: function(e) {
        var t = this.data.beizhu;
        if (console.log("form发生了submit事件，携带数据为：", e.detail.value), "wxzf" == e.detail.value.radiogroup) a = 2;
        if ("yezf" == e.detail.value.radiogroup) a = 1;
        if ("chzf" == e.detail.value.radiogroup) a = 0;
        if ("jfzf" == e.detail.value.radiogroup) var a = 3;
        var o = this;
        console.log(o.data);
        var s = o.data.store.id;
        console.log(s);
        var i = o.data.order, n = wx.getStorageSync("openid"), l = e.detail.formId;
        console.log(l);
        var c = wx.getStorageSync("users").id;
        if (null == o.data.coupons_id) {
            console.log("用户没有选择优惠券");
            r = "";
        } else {
            console.log("用户选择了优惠券");
            var r = o.data.coupons_id;
        }
        if (null == o.data.vouchers_id) {
            console.log("用户没有选择代金券");
            u = "";
        } else {
            console.log("用户选择了代金券");
            var u = o.data.vouchers_id;
        }
        console.log("代金券id" + u), console.log("优惠券id" + r);
        var d = o.data.pre + Number(o.data.cut), p = (Number(o.data.totalPrice), Number(o.data.zfmoney));
        if (console.log(p), "yezf" == e.detail.value.radiogroup) {
            var f = Number(this.data.wallet);
            if (console.log(f, p), f < p) return void wx.showToast({
                title: "余额不足支付",
                icon: "loading"
            });
        }
        var g = 0;
        if ("jfzf" == e.detail.value.radiogroup) {
            var m = Number(this.data.total_score) / Number(this.data.jf_proportion);
            if (g = p * Number(this.data.jf_proportion), console.log(m, p, g), m < p) return void wx.showToast({
                title: "积分不足支付",
                icon: "loading"
            });
        }
        console.log(2);
        var h = o.data.table_id;
        console.log("桌号" + h);
        var y = o.data.tabletype_id;
        console.log("桌子类型" + y);
        var w = [];
        i.map(function(e) {
            if (e.num > 0) {
                var t = {};
                t.name = e.name, t.img = e.icon, t.num = e.num, t.money = e.money, t.dishes_id = e.id, 
                w.push(t);
            }
        }), console.log(w), p <= 0 ? wx.showToast({
            title: "金额不能为0",
            icon: "",
            image: "",
            duration: 2e3,
            mask: !0,
            success: function(e) {},
            fail: function(e) {},
            complete: function(e) {}
        }) : (this.setData({
            zfz: !0
        }), app.util.request({
            url: "entry/wxapp/AddOrder",
            cachetime: "0",
            data: {
                type: 2,
                money: p,
                user_id: c,
                table_id: h,
                seller_id: s,
                coupons_id: r,
                voucher_id: u,
                preferential: d,
                sz: w,
                is_yue: a,
                note: t,
                form_id: l,
                jf: g
            },
            success: function(t) {
                var a = t.data;
                console.log("本次的订单id为" + a), "下单失败" != a && (o.setData({
                    zfz: !1,
                    showModal: !1
                }), "yezf" == e.detail.value.radiogroup && (console.log("用户选择余额支付"), app.util.request({
                    url: "entry/wxapp/PayOrder",
                    cachetime: "0",
                    data: {
                        user_id: c,
                        order_id: a,
                        coupons_id: r,
                        voucher_id: u
                    },
                    success: function(e) {
                        console.log(e), wx.showModal({
                            title: "提示",
                            content: "支付成功",
                            showCancel: !1
                        }), setTimeout(function() {
                            wx.switchTab({
                                url: "../list/list"
                            });
                        }, 1e3), app.util.request({
                            url: "entry/wxapp/DnPrint",
                            cachetime: "0",
                            data: {
                                order_id: a,
                                pay_type: "余额支付"
                            },
                            success: function(e) {
                                console.log(e);
                            }
                        }), app.util.request({
                            url: "entry/wxapp/DnPrint2",
                            cachetime: "0",
                            data: {
                                order_id: a,
                                pay_type: "余额支付"
                            },
                            success: function(e) {
                                console.log(e);
                            }
                        }), app.util.request({
                            url: "entry/wxapp/SmsSet",
                            cachetime: "0",
                            data: {
                                store_id: s
                            },
                            success: function(e) {
                                console.log(e), "1" == e.data.is_dnsms && app.util.request({
                                    url: "entry/wxapp/sms",
                                    cachetime: "0",
                                    data: {
                                        store_id: s
                                    },
                                    success: function(e) {
                                        console.log(e);
                                    }
                                });
                            }
                        });
                    }
                })), "jfzf" == e.detail.value.radiogroup && (console.log("用户选择积分支付"), app.util.request({
                    url: "entry/wxapp/PayOrder",
                    cachetime: "0",
                    data: {
                        user_id: c,
                        order_id: a,
                        coupons_id: r,
                        voucher_id: u
                    },
                    success: function(e) {
                        console.log(e), wx.showModal({
                            title: "提示",
                            content: "支付成功",
                            showCancel: !1
                        }), setTimeout(function() {
                            wx.switchTab({
                                url: "../list/list"
                            });
                        }, 1e3), app.util.request({
                            url: "entry/wxapp/DnPrint",
                            cachetime: "0",
                            data: {
                                order_id: a,
                                pay_type: "积分支付"
                            },
                            success: function(e) {
                                console.log(e);
                            }
                        }), app.util.request({
                            url: "entry/wxapp/DnPrint2",
                            cachetime: "0",
                            data: {
                                order_id: a,
                                pay_type: "积分支付"
                            },
                            success: function(e) {
                                console.log(e);
                            }
                        }), app.util.request({
                            url: "entry/wxapp/SmsSet",
                            cachetime: "0",
                            data: {
                                store_id: s
                            },
                            success: function(e) {
                                console.log(e), "1" == e.data.is_dnsms && app.util.request({
                                    url: "entry/wxapp/sms",
                                    cachetime: "0",
                                    data: {
                                        store_id: s
                                    },
                                    success: function(e) {
                                        console.log(e);
                                    }
                                });
                            }
                        });
                    }
                })), "wxzf" == e.detail.value.radiogroup && (console.log("用户选择微信支付"), app.util.request({
                    url: "entry/wxapp/pay",
                    cachetime: "0",
                    data: {
                        openid: n,
                        order_id: a,
                        money: p
                    },
                    success: function(e) {
                        console.log(e), wx.requestPayment({
                            timeStamp: e.data.timeStamp,
                            nonceStr: e.data.nonceStr,
                            package: e.data.package,
                            signType: e.data.signType,
                            paySign: e.data.paySign,
                            success: function(e) {
                                console.log(e.data), console.log(e);
                            },
                            complete: function(e) {
                                "requestPayment:fail cancel" == e.errMsg && (wx.showToast({
                                    title: "取消支付"
                                }), setTimeout(function() {
                                    wx.switchTab({
                                        url: "../list/list"
                                    });
                                }, 1e3)), "requestPayment:ok" == e.errMsg && (wx.showModal({
                                    title: "提示",
                                    content: "支付成功",
                                    showCancel: !1
                                }), setTimeout(function() {
                                    wx.switchTab({
                                        url: "../list/list"
                                    });
                                }, 1e3));
                            }
                        });
                    }
                })), "chzf" == e.detail.value.radiogroup && (console.log("用户选择餐后支付"), wx.showModal({
                    title: "提示",
                    content: "下单成功",
                    showCancel: !1
                }), app.util.request({
                    url: "entry/wxapp/DnPrint",
                    cachetime: "0",
                    data: {
                        order_id: a,
                        pay_type: "餐后支付"
                    },
                    success: function(e) {
                        console.log(e);
                    }
                }), app.util.request({
                    url: "entry/wxapp/DnPrint2",
                    cachetime: "0",
                    data: {
                        order_id: a,
                        pay_type: "餐后支付"
                    },
                    success: function(e) {
                        console.log(e);
                    }
                }), app.util.request({
                    url: "entry/wxapp/SmsSet",
                    cachetime: "0",
                    data: {
                        store_id: s
                    },
                    success: function(e) {
                        console.log(e), "1" == e.data.is_dnsms && app.util.request({
                            url: "entry/wxapp/sms",
                            cachetime: "0",
                            data: {
                                store_id: s
                            },
                            success: function(e) {
                                console.log(e);
                            }
                        });
                    }
                }), wx.switchTab({
                    url: "../list/list"
                })));
            }
        }));
    },
    bindPickerChange: function(e) {
        var t = this;
        console.log("picker发送选择改变，携带值为", e.detail.value);
        var a = e.detail.value;
        t.setData({
            index: a,
            inde: 0
        }), console.log(t.data), app.util.request({
            url: "entry/wxapp/TableType",
            cachetime: "0",
            success: function(e) {
                var o = e.data[a].id;
                app.util.request({
                    url: "entry/wxapp/Table",
                    cachetime: "0",
                    data: {
                        type_id: o
                    },
                    success: function(e) {
                        console.log(e), t.setData({
                            not_use: e.data,
                            tabletype_id: o,
                            table_id: e.data[t.data.inde].id
                        });
                    }
                });
            }
        });
    },
    bindPickerChange_one: function(e) {
        var t = this;
        if (console.log(t.data), 0 != t.data.index) ;
        var a = t.data.tabletype_id;
        app.util.request({
            url: "entry/wxapp/Table",
            cachetime: "0",
            data: {
                type_id: a
            },
            success: function(e) {
                console.log(e), t.setData({
                    not_use: e.data,
                    table_id: e.data[t.data.inde].id
                });
            }
        }), console.log("picker发送选择改变，携带值为", e.detail.value), t.setData({
            inde: e.detail.value,
            value: e.detail.value
        });
    },
    onReady: function() {},
    onShow: function() {
        app.util.request({
            url: "entry/wxapp/Store",
            cachetime: "0",
            data: {
                id: getApp().sjid
            },
            success: function(e) {
                console.log(e), wx.setNavigationBarColor({
                    frontColor: "#ffffff",
                    backgroundColor: e.data.color
                });
            }
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});