var app = getApp();

Page({
    data: {
        text: "微擎我的"
    },
    onLoad: function(n) {
        app.util.footer(this);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {}
});