var siteinfo = {
    name: "说图谱源码网",
    uniacid: "16",
    acid: "16",
    multiid: "0",
    version: "6.62",
    siteroot: "https://www.shuotupu.com/app/index.php",
    design_method: "1"
};

module.exports = siteinfo;