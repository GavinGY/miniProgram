﻿var siteinfo = {
  name: "餐饮外卖",
    uniacid: "38",
    acid: "38",
    multiid: "0",
    version: "9.2",
    siteroot: "https://www5.sichuanjiakao.com/app/index.php",
    design_method: "3"
};

module.exports = siteinfo;