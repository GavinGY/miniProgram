<?php

class YLYConfigClient{

    static $YLYClientId = '1062809662';
    static $YLYClientSecret = '467fac12be61a1288d4b016b716f9b4b';
    static $YLYRequestUrl = 'https://open-api.10ss.net';

}