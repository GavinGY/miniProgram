<?php
global $_GPC, $_W;
$GLOBALS['frames'] = $this->getMainMenu2();

include $this->template('web/storeinfo');